# AI Usage

> Review and edit this file so it reflects what YOU actually did. Items marked **[YOU]** need your own input.

## Tool used
**Claude (Anthropic)** via claude.ai, given the assignment documents.

## What it was used for
- Designing the project structure and the common data model
- Writing the scrapers, cleaning, validation, deduplication, `main.py`, tests, README and this file's first draft

## Representative prompt
"Here are the assignment documents" followed by "build the full project, explain the design, and review my code."
**[YOU]** Add your own follow-up prompts here.

## AI-assisted parts
Essentially all code was drafted by the AI. **[YOU]** Note anything you rewrote or wrote yourself.

## Verification done during drafting
- 23 unit/integration tests pass offline (`python -m pytest`), using HTML fixtures that mimic both sites:
  cleaning, validation, dedup (including case/space/punctuation variants), pagination via the `next` link,
  a missing price element, a failed detail page, a failed listing page, a crashing source, and count reconciliation.
- The AI's sandbox could not reach the real sites (403 from its network proxy), so **no live run was done by the AI**.

## Changes after review / problems found
**[YOU]** Fill in after running it. Examples to check honestly:
- Does the live run return ~1,000 books over 50 pages and 100 quotes over 10 pages?
- Do the JSON counts match the CSV row count?
- Any selector or encoding issues (e.g. `Â£`) on the real pages?

## Final testing
**[YOU]** Record your clean-environment run: new venv, `pip install -r requirements.txt`, `python main.py`,
and what you saw in the CSV, JSON and log.
