"""Books to Scrape: selectors and parsing only. Raw text is returned exactly as found."""
import logging
from urllib.parse import urljoin

from scrapers.base_scraper import BaseScraper

logger = logging.getLogger(__name__)


class BooksScraper(BaseScraper):
    source_name = "Books to Scrape"
    start_url = "https://books.toscrape.com/"

    def __init__(self, *args, fetch_details=True, **kwargs):
        super().__init__(*args, **kwargs)
        self.fetch_details = fetch_details  # detail pages give category + description (1 request per book)

    def parse_book(self, article, page_url):
        link = article.select_one("h3 > a")
        price = article.select_one("p.price_color")
        rating = article.select_one("p.star-rating")
        return {
            # the visible link text is cut off with '...', the full title is in the title attribute
            "title": link.get("title") if link else None,
            "href": urljoin(page_url, link["href"]) if link and link.get("href") else None,
            "price_raw": price.get_text() if price else None,
            "rating_raw": " ".join(rating.get("class", [])) if rating else None,
            "category_raw": None,
            "description_raw": None,
        }

    def parse_detail(self, soup):
        crumbs = soup.select("ul.breadcrumb li")  # Home > Books > <Category> > <Title>
        category = crumbs[2].get_text() if len(crumbs) >= 3 else None
        desc_header = soup.select_one("#product_description")
        desc_p = desc_header.find_next_sibling("p") if desc_header else None
        return {"category_raw": category, "description_raw": desc_p.get_text() if desc_p else None}

    def parse_page(self, soup, page_url):
        records = []
        for article in soup.select("article.product_pod"):
            try:
                rec = self.parse_book(article, page_url)
            except Exception:
                logger.exception("[%s] Skipping unparsable book on %s", self.source_name, page_url)
                continue
            if self.fetch_details and rec["href"]:
                self.pause()
                detail = self.fetch(rec["href"])
                if detail is None:
                    logger.warning("[%s] No detail page for %r, category/description left empty",
                                   self.source_name, rec["title"])
                else:
                    try:
                        rec.update(self.parse_detail(detail))
                    except Exception:
                        logger.exception("[%s] Bad detail page %s", self.source_name, rec["href"])
            records.append(rec)
        return records
