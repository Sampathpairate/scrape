"""Shared networking + dynamic pagination. Anything that touches the internet lives in scrapers/."""
import logging
import time
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

logger = logging.getLogger(__name__)


def create_session() -> requests.Session:
    """One session with a User-Agent and automatic retries (backoff 1s, 2s, 4s) for temporary errors."""
    session = requests.Session()
    session.headers.update({"User-Agent": "ScrapingAssignment/1.0 (learning project)"})
    retries = Retry(total=3, backoff_factor=1.0, status_forcelist=[429, 500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retries)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


class BaseScraper:
    """Subclasses set source_name/start_url and implement parse_page()."""

    source_name = ""
    start_url = ""

    def __init__(self, session=None, delay=0.5, timeout=10, max_pages=None):
        self.session = session or create_session()
        self.delay = delay
        self.timeout = timeout
        self.max_pages = max_pages  # None = follow "next" until it disappears
        self.stats = {"pages_fetched": 0, "pages_failed": 0}

    def pause(self):
        if self.delay:
            time.sleep(self.delay)

    def fetch(self, url):
        """Download and parse one page. Returns a soup, or None if the request failed."""
        try:
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
            response.encoding = "utf-8"  # otherwise the pound sign can show up as 'Â£'
            return BeautifulSoup(response.text, "lxml")
        except requests.RequestException as exc:
            logger.error("Failed to fetch %s: %s", url, exc)
            return None

    def parse_page(self, soup, page_url):
        raise NotImplementedError

    def scrape(self):
        """Follow the 'next' link until there is none. Never hard-codes a page count."""
        url, page, records, visited = self.start_url, 1, [], set()
        while url and (self.max_pages is None or page <= self.max_pages):
            if url in visited:  # guard against a next-link loop
                logger.warning("[%s] Already visited %s, stopping", self.source_name, url)
                break
            visited.add(url)
            logger.info("[%s] Page %d: %s", self.source_name, page, url)

            soup = self.fetch(url)
            if soup is None:
                self.stats["pages_failed"] += 1
                logger.error("[%s] Stopping source after failed page %d", self.source_name, page)
                break
            self.stats["pages_fetched"] += 1

            try:
                page_records = self.parse_page(soup, url)
            except Exception:  # a broken page layout must not kill the run
                logger.exception("[%s] Could not parse page %s", self.source_name, url)
                page_records = []
            logger.info("[%s] Page %d gave %d records", self.source_name, page, len(page_records))
            records.extend(page_records)

            next_link = soup.select_one("li.next > a")
            url = urljoin(url, next_link["href"]) if next_link and next_link.get("href") else None
            page += 1
            if url:
                self.pause()
        return records
