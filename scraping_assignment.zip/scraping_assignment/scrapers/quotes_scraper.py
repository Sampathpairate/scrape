"""Quotes to Scrape: selectors and parsing only."""
import logging

from scrapers.base_scraper import BaseScraper

logger = logging.getLogger(__name__)


class QuotesScraper(BaseScraper):
    source_name = "Quotes to Scrape"
    start_url = "https://quotes.toscrape.com/"

    def parse_quote(self, div, page_url):
        text = div.select_one("span.text")
        author = div.select_one("small.author")
        return {
            "text": text.get_text() if text else None,
            "author": author.get_text() if author else None,
            "tags": [t.get_text() for t in div.select("a.tag")],  # zero or more
            "page_url": page_url,  # documented choice: source_url = page where the quote appeared
        }

    def parse_page(self, soup, page_url):
        records = []
        for div in soup.select("div.quote"):
            try:
                records.append(self.parse_quote(div, page_url))
            except Exception:
                logger.exception("[%s] Skipping unparsable quote on %s", self.source_name, page_url)
        return records
