"""Small pure functions: value in, cleaned value out. No internet, no files."""
import re

RATING_MAP = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}
QUOTE_CHARS = "\u201c\u201d\"\u2018\u2019'"

COLUMNS = ["source", "source_url", "name_or_title", "category", "price",
           "rating", "author", "tags", "description", "scraped_at"]


def clean_text(value):
    """Collapse tabs/newlines/non-breaking spaces; empty becomes None."""
    if value is None:
        return None
    text = " ".join(str(value).replace("\xa0", " ").split())
    return text or None


def strip_quotes(value):
    """Remove the curly (or straight) quotation marks wrapped around a quote."""
    text = clean_text(value)
    if text is None:
        return None
    return text.strip(QUOTE_CHARS).strip() or None


def clean_price(raw):
    """'£51.77' -> 51.77. Returns None if there is no number."""
    if not raw:
        return None
    match = re.search(r"\d+(?:\.\d+)?", str(raw).replace(",", ""))
    return float(match.group()) if match else None


def clean_rating(raw):
    """'star-rating Three' -> 3. Returns None if no rating word is found."""
    for word in str(raw or "").lower().split():
        if word in RATING_MAP:
            return RATING_MAP[word]
    return None


def clean_tags(tags):
    """Lowercase, trim, drop empties and repeats, sort, join with ';'."""
    cleaned = {clean_text(t).lower() for t in (tags or []) if clean_text(t)}
    return ";".join(sorted(cleaned)) or None


def normalize_url(url):
    """Return a trimmed http(s) URL, or None when it is missing or not valid-looking."""
    url = clean_text(url)
    if url and url.lower().startswith(("http://", "https://")):
        return url
    return None


def clean_book(raw, scraped_at):
    return {
        "source": "Books to Scrape",
        "source_url": normalize_url(raw.get("href")),
        "name_or_title": clean_text(raw.get("title")),
        "category": clean_text(raw.get("category_raw")),
        "price": clean_price(raw.get("price_raw")),
        "rating": clean_rating(raw.get("rating_raw")),
        "author": None,
        "tags": None,
        "description": clean_text(raw.get("description_raw")),
        "scraped_at": scraped_at,
    }


def clean_quote(raw, scraped_at):
    return {
        "source": "Quotes to Scrape",
        "source_url": normalize_url(raw.get("page_url")),
        "name_or_title": strip_quotes(raw.get("text")),
        "category": None,
        "price": None,
        "rating": None,
        "author": clean_text(raw.get("author")),
        "tags": clean_tags(raw.get("tags")),
        "description": None,
        "scraped_at": scraped_at,
    }


CLEANERS = {"Books to Scrape": clean_book, "Quotes to Scrape": clean_quote}
