"""Fingerprint-based duplicate detection. Duplicates are REMOVED (and counted + logged)."""
import hashlib
import logging
import re

logger = logging.getLogger(__name__)


def make_fingerprint(rec):
    """Books: source + title. Quotes: source + author + first 50 chars of the quote."""
    source = rec.get("source") or ""
    title = rec.get("name_or_title") or ""
    if source == "Books to Scrape":
        key = f"{source} {title}"
    else:
        key = f"{source} {rec.get('author') or ''} {title[:50]}"
    key = re.sub(r"[^\w\s]", "", key.lower())  # lowercase, drop punctuation
    key = " ".join(key.split())                # collapse spaces
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def find_duplicates(records):
    """Return (unique, duplicates). The first occurrence is kept."""
    seen, unique, dupes = set(), [], []
    for rec in records:
        fp = make_fingerprint(rec)
        if fp in seen:
            dupes.append(rec)
            logger.warning("Duplicate removed: %s | %s", rec.get("source"), rec.get("name_or_title"))
        else:
            seen.add(fp)
            unique.append(rec)
    return unique, dupes
