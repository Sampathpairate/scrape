# Multi-Source Web Scraping & Data Consolidation

A small ETL pipeline: scrape **Books to Scrape** and **Quotes to Scrape**, clean, validate, deduplicate,
and write one tidy CSV plus a JSON summary and a log file. One command runs everything.

## Python version
Python 3.10 - 3.12 (developed on 3.12).

## Setup
```
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
Dependencies: `requests`, `beautifulsoup4`, `lxml` (+ `pytest` for tests). No accounts or API keys.

## How to run
```
python main.py                 # full run (about 1,000 book detail pages, roughly 10 minutes)
python main.py --no-details    # fast run: skips book detail pages (category/description stay empty)
python main.py --max-pages 2   # quick smoke test
python -m pytest               # unit + offline pipeline tests (no internet needed)
```
Other flags: `--delay` (default 0.5s between requests), `--output-dir`, `--log-file`.

## Outputs
| File | Contents |
| --- | --- |
| `output/final_dataset.csv` | One row per unique, valid record, same columns for every row |
| `output/summary_report.json` | Per-source pages, raw, cleaned, rejected (by reason), duplicates, final, plus run time |
| `logs/scraper.log` | Every page, warning (rejected/duplicate record) and error |

The summary's `reconciles` flag checks `raw - rejected - duplicates = final = CSV rows`.

## Site exploration (Stage 1 observations)
| Item | Books to Scrape | Quotes to Scrape |
| --- | --- | --- |
| One record | `article.product_pod` | `div.quote` |
| Main text | `h3 > a` (full title in the `title` attribute; visible text is cut with `...`) | `span.text` (curly quotes) |
| Price / rating | `p.price_color` (`£51.77`) / class on `p.star-rating` (`Three`) | none |
| Author / tags | none | `small.author` / `a.tag` (zero or more) |
| Link | `h3 > a[href]` (relative) | page URL |
| Next page | `li.next > a` (relative) | `li.next > a` (relative) |
| Detail page | breadcrumb gives category, `#product_description + p` gives description | n/a |

## How pagination works
`BaseScraper.scrape()` starts at the home page, parses it, then looks for `li.next > a`. If found, it joins the
relative href to the current URL with `urljoin` and repeats; if not, it stops. No page count is hard-coded, and a
visited-URL set guards against a next-link loop.

## Data model
Columns: `source, source_url, name_or_title, category, price, rating, author, tags, description, scraped_at`.
Fields that do not apply are left empty (never invented, e.g. quotes have no price of 0).

| Column | Books | Quotes |
| --- | --- | --- |
| `source_url` | book detail page URL | page where the quote appeared (chosen and documented) |
| `name_or_title` | full title | quote text without curly quotes |
| `category` / `description` | from detail page | empty |
| `price` / `rating` | float / int 1-5 | empty |
| `author` / `tags` | empty | author / `tag1;tag2` (lowercase, sorted, unique) |
| `scraped_at` | UTC ISO timestamp | UTC ISO timestamp |

## Cleaning (`processing/cleaning.py`)
Pure functions, testable with plain strings: `clean_text` (collapses spaces/tabs/newlines/`\xa0`, empty -> `None`),
`strip_quotes`, `clean_price` (`£51.77` -> `51.77`), `clean_rating` (`Three` -> `3`), `clean_tags`, `normalize_url`.
Responses are decoded as UTF-8 so `£` is not read as `Â£`.

## Validation (`processing/validation.py`)
Returns a list of reasons: `unknown_source`, `missing_name`, `invalid_url`, `invalid_price` (non-number or < 0),
`invalid_rating` (not 1-5). Invalid records are logged as warnings, counted by reason, and excluded.
A record with two problems counts once as rejected but under both reasons.

## Deduplication (`processing/deduplication.py`)
Fingerprint = SHA-256 of the lowercase, punctuation-free, space-collapsed key:
- Books: `source + title`
- Quotes: `source + author + first 50 characters of the quote`

The first occurrence is kept; later ones are **removed** (logged and counted). Removal was chosen because the output
is a clean analysis table and the logs/summary already record what was dropped. The real sites contain no duplicates,
so the logic is proven by unit tests with deliberately duplicated data.

## Error handling
- HTTP session with timeout and retries (429/500/502/503/504, backoff 1s/2s/4s).
- A failed page is logged and stops **that source only**; records already collected are kept.
- A failed book detail page leaves category/description empty; the book is kept.
- Each record is parsed in `try/except`; missing elements return `None` instead of crashing.
- Each source runs inside its own `try/except` in `main.py`; cleaning errors are counted as `cleaning_error`.

## Assumptions
- Quote `source_url` is the listing page, since the quote itself has no page of its own.
- Fetching book detail pages is on by default so category and description are real data, not guesses.

## Known limitations
- Requests are sequential (polite but slow with detail pages); no checkpoint/resume.
- If a listing page fails after retries, later pages of that source are not scraped.
- Duplicate rules use title (books) and author + 50 chars (quotes); two different books with the same title would merge.
- Selectors are tied to the current site layout.

## AI usage summary
See `AI_USAGE.md`.
