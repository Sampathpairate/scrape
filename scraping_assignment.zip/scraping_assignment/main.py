"""Run the whole ETL job:  python main.py
Scrape -> Clean -> Validate -> Deduplicate -> Consolidate -> Save files
"""
import argparse
import csv
import json
import logging
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from processing.cleaning import CLEANERS, COLUMNS
from processing.deduplication import find_duplicates
from processing.validation import validate_record
from scrapers.books_scraper import BooksScraper
from scrapers.quotes_scraper import QuotesScraper

logger = logging.getLogger("main")
BASE_DIR = Path(__file__).resolve().parent


def setup_logging(log_file):
    log_file = Path(log_file)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers.clear()
    for handler in (logging.StreamHandler(), logging.FileHandler(log_file, mode="w", encoding="utf-8")):
        handler.setFormatter(fmt)
        root.addHandler(handler)


def process_source(scraper):
    """Scrape one source, then clean + validate. Never raises: a failure is reported in the stats."""
    name = scraper.source_name
    stats = {"pages_fetched": 0, "pages_failed": 0, "raw_collected": 0, "cleaned": 0,
             "rejected_total": 0, "rejected_reasons": Counter(), "duplicates": 0, "final": 0, "error": None}
    valid = []
    try:
        raw_records = scraper.scrape()
    except Exception as exc:
        logger.exception("[%s] Scraping crashed, continuing with other sources", name)
        stats["error"] = f"{type(exc).__name__}: {exc}"
        raw_records = []
    stats.update(scraper.stats)
    stats["raw_collected"] = len(raw_records)

    scraped_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    cleaner = CLEANERS[name]
    for raw in raw_records:
        try:
            rec = cleaner(raw, scraped_at)
        except Exception as exc:  # unexpected data format
            logger.warning("[%s] Cleaning failed (%s): %r", name, exc, raw)
            stats["rejected_total"] += 1
            stats["rejected_reasons"]["cleaning_error"] += 1
            continue
        stats["cleaned"] += 1
        problems = validate_record(rec)
        if problems:
            logger.warning("[%s] Rejected %r: %s", name, rec.get("name_or_title"), ", ".join(problems))
            stats["rejected_total"] += 1
            stats["rejected_reasons"].update(problems)  # a record with 2 problems counts under both reasons
            continue
        valid.append(rec)
    return valid, stats


def run_pipeline(scrapers, output_dir):
    start = datetime.now(timezone.utc)
    t0 = time.perf_counter()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_valid, per_source = [], {}
    for scraper in scrapers:
        valid, stats = process_source(scraper)
        all_valid.extend(valid)
        per_source[scraper.source_name] = stats

    unique, dupes = find_duplicates(all_valid)
    for rec in dupes:
        per_source[rec["source"]]["duplicates"] += 1
    for rec in unique:
        per_source[rec["source"]]["final"] += 1

    csv_path = output_dir / "final_dataset.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(unique)

    totals = {"raw_collected": 0, "cleaned": 0, "rejected": 0, "duplicates": 0, "final": 0}
    for stats in per_source.values():
        totals["raw_collected"] += stats["raw_collected"]
        totals["cleaned"] += stats["cleaned"]
        totals["rejected"] += stats["rejected_total"]
        totals["duplicates"] += stats["duplicates"]
        totals["final"] += stats["final"]
        stats["rejected_reasons"] = dict(stats["rejected_reasons"])
    # raw - rejected - duplicates must equal final, and final must equal the CSV row count
    totals["reconciles"] = (totals["raw_collected"] - totals["rejected"] - totals["duplicates"]
                            == totals["final"] == len(unique))

    end = datetime.now(timezone.utc)
    report = {
        "run": {"start_time": start.isoformat(timespec="seconds"),
                "end_time": end.isoformat(timespec="seconds"),
                "duration_seconds": round(time.perf_counter() - t0, 2)},
        "sources": per_source,
        "totals": totals,
    }
    with open(output_dir / "summary_report.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, ensure_ascii=False)
    logger.info("Done: %d final rows written to %s (reconciles=%s)", len(unique), csv_path, totals["reconciles"])
    return report


def parse_args():
    p = argparse.ArgumentParser(description="Multi-source scraping + consolidation pipeline")
    p.add_argument("--no-details", action="store_true",
                   help="skip book detail pages (much faster; category/description stay empty)")
    p.add_argument("--delay", type=float, default=0.5, help="seconds between requests (default 0.5)")
    p.add_argument("--max-pages", type=int, default=None, help="limit pages per source (for quick tests)")
    p.add_argument("--output-dir", default=str(BASE_DIR / "output"))
    p.add_argument("--log-file", default=str(BASE_DIR / "logs" / "scraper.log"))
    return p.parse_args()


def main():
    args = parse_args()
    setup_logging(args.log_file)
    scrapers = [
        BooksScraper(delay=args.delay, max_pages=args.max_pages, fetch_details=not args.no_details),
        QuotesScraper(delay=args.delay, max_pages=args.max_pages),
    ]
    run_pipeline(scrapers, args.output_dir)


if __name__ == "__main__":
    main()
