"""Tiny offline stand-ins for the two sites, so parsing and the full pipeline can be tested without internet."""
import requests


class FakeResponse:
    def __init__(self, text):
        self.text = text
        self.encoding = None

    def raise_for_status(self):
        pass


class FakeSession:
    """Serves pages from a dict. A value of None simulates a connection failure."""

    def __init__(self, pages):
        self.pages = pages
        self.requested = []

    def get(self, url, timeout=None):
        self.requested.append(url)
        if self.pages.get(url) is None:
            raise requests.ConnectionError(f"simulated failure for {url}")
        return FakeResponse(self.pages[url])


def book_html(title, href, price="\u00a351.77", rating="Three", with_price=True):
    price_html = f'<p class="price_color">{price}</p>' if with_price else ""
    t = f'title="{title}"' if title is not None else ""
    return (f'<article class="product_pod"><p class="star-rating {rating}"></p>'
            f'<h3><a href="{href}" {t}>{(title or "")[:10]}...</a></h3>{price_html}</article>')


def books_page(items, next_href=None):
    nxt = f'<li class="next"><a href="{next_href}">next</a></li>' if next_href else ""
    return f"<html><body>{''.join(items)}<ul class='pager'>{nxt}</ul></body></html>"


def book_detail(category, desc):
    d = f'<div id="product_description"></div><p>{desc}</p>' if desc else ""
    return ('<html><body><ul class="breadcrumb"><li>Home</li><li>Books</li>'
            f'<li><a>{category}</a></li><li>Title</li></ul>{d}</body></html>')


def quote_html(text, author, tags):
    tag_html = "".join(f'<a class="tag">{t}</a>' for t in tags)
    return (f'<div class="quote"><span class="text">\u201c{text}\u201d</span>'
            f'<span>by <small class="author">{author}</small></span><div class="tags">{tag_html}</div></div>')


def quotes_page(items, next_href=None):
    nxt = f'<li class="next"><a href="{next_href}">next</a></li>' if next_href else ""
    return f"<html><body>{''.join(items)}<ul class='pager'>{nxt}</ul></body></html>"
