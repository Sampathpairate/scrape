from processing.deduplication import find_duplicates, make_fingerprint


def test_duplicates_ignore_case_and_spaces():
    base = {"source": "Books to Scrape", "author": None}
    records = [{**base, "name_or_title": "Example Book Title"},
               {**base, "name_or_title": "  Example Book Title "},
               {**base, "name_or_title": "EXAMPLE BOOK TITLE"}]
    unique, dupes = find_duplicates(records)
    assert len(unique) == 1 and len(dupes) == 2


def test_quotes_use_author_and_first_50_chars():
    q = {"source": "Quotes to Scrape", "author": "Albert Einstein"}
    a = {**q, "name_or_title": "x" * 50 + " ending one"}
    b = {**q, "name_or_title": "X" * 50 + " ENDING TWO"}      # same first 50 chars -> duplicate
    c = {**q, "author": "Someone Else", "name_or_title": "x" * 50}  # other author -> different
    unique, dupes = find_duplicates([a, b, c])
    assert len(unique) == 2 and dupes == [b]


def test_same_title_different_source_is_not_duplicate():
    t = "Same"
    assert make_fingerprint({"source": "Books to Scrape", "name_or_title": t}) != \
        make_fingerprint({"source": "Quotes to Scrape", "name_or_title": t, "author": ""})


def test_first_occurrence_kept():
    r1 = {"source": "Books to Scrape", "name_or_title": "A", "price": 1}
    r2 = {"source": "Books to Scrape", "name_or_title": "a", "price": 2}
    unique, _ = find_duplicates([r1, r2])
    assert unique == [r1]
