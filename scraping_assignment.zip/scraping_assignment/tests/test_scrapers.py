from scrapers.books_scraper import BooksScraper
from scrapers.quotes_scraper import QuotesScraper
from tests.fakesite import (FakeSession, book_detail, book_html, books_page, quote_html, quotes_page)

B = "https://books.toscrape.com/"
Q = "https://quotes.toscrape.com/"


def test_books_pagination_follows_next_and_reads_details():
    pages = {
        B: books_page([book_html("A Very Long Book Title", "catalogue/a_1/index.html")], "catalogue/page-2.html"),
        B + "catalogue/page-2.html": books_page([book_html("Second Book Title", "b_2/index.html")]),
        B + "catalogue/a_1/index.html": book_detail("Travel", "A description"),
        B + "catalogue/b_2/index.html": book_detail("Poetry", None),
    }
    session = FakeSession(pages)
    recs = BooksScraper(session=session, delay=0).scrape()
    assert [r["title"] for r in recs] == ["A Very Long Book Title", "Second Book Title"]  # full title, not '...'
    assert recs[0]["category_raw"] == "Travel" and recs[0]["description_raw"] == "A description"
    assert recs[1]["category_raw"] == "Poetry" and recs[1]["description_raw"] is None
    assert recs[1]["href"] == B + "catalogue/b_2/index.html"  # relative link made absolute


def test_missing_price_element_does_not_crash():
    pages = {B: books_page([book_html("No Price Book", "x/index.html", with_price=False)])}
    recs = BooksScraper(session=FakeSession(pages), delay=0, fetch_details=False).scrape()
    assert len(recs) == 1 and recs[0]["price_raw"] is None


def test_failed_detail_page_keeps_record():
    pages = {B: books_page([book_html("Book", "x/index.html")]), B + "x/index.html": None}
    recs = BooksScraper(session=FakeSession(pages), delay=0).scrape()
    assert len(recs) == 1 and recs[0]["category_raw"] is None


def test_failed_page_stops_source_but_returns_earlier_records():
    pages = {Q: quotes_page([quote_html("One", "A", ["x"])], "/page/2/"), Q + "page/2/": None}
    s = QuotesScraper(session=FakeSession(pages), delay=0)
    recs = s.scrape()
    assert len(recs) == 1 and s.stats == {"pages_fetched": 1, "pages_failed": 1}


def test_quotes_parse_multiple_and_zero_tags():
    pages = {Q: quotes_page([quote_html("One", "A", ["x", "y"]), quote_html("Two", "B", [])])}
    recs = QuotesScraper(session=FakeSession(pages), delay=0).scrape()
    assert recs[0]["tags"] == ["x", "y"] and recs[1]["tags"] == []
    assert recs[0]["page_url"] == Q


def test_max_pages_limits_crawl():
    pages = {Q: quotes_page([quote_html("One", "A", [])], "/page/2/"),
             Q + "page/2/": quotes_page([quote_html("Two", "B", [])])}
    assert len(QuotesScraper(session=FakeSession(pages), delay=0, max_pages=1).scrape()) == 1
