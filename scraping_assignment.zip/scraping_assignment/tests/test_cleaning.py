from processing.cleaning import (clean_price, clean_rating, clean_tags, clean_text,
                                 normalize_url, strip_quotes, clean_book, clean_quote)


def test_clean_text():
    assert clean_text("  Hello \n World ") == "Hello World"
    assert clean_text("a\xa0b") == "a b"
    assert clean_text("   ") is None
    assert clean_text(None) is None


def test_strip_quotes():
    assert strip_quotes("\u201cTo be, or not.\u201d") == "To be, or not."
    assert strip_quotes("\u201cIt's fine\u201d") == "It's fine"  # inner apostrophe untouched
    assert strip_quotes("\u201c\u201d") is None


def test_clean_price():
    assert clean_price("\u00a351.77") == 51.77
    assert clean_price("\u00c2\u00a351.77") == 51.77  # mis-decoded pound sign still works
    assert clean_price("\u00a31,051.00") == 1051.0
    assert clean_price("free") is None
    assert clean_price(None) is None


def test_clean_rating():
    assert clean_rating("star-rating Three") == 3
    assert clean_rating("Five") == 5
    assert clean_rating("star-rating") is None
    assert clean_rating(None) is None


def test_clean_tags():
    assert clean_tags(["Love", " books ", "love", ""]) == "books;love"
    assert clean_tags([]) is None


def test_normalize_url():
    assert normalize_url(" https://a.com/x ") == "https://a.com/x"
    assert normalize_url("/relative/path") is None
    assert normalize_url(None) is None


def test_clean_book_and_quote_shapes():
    book = clean_book({"title": " T ", "href": "https://x/b", "price_raw": "\u00a35.00",
                       "rating_raw": "star-rating Two"}, "t")
    assert book["price"] == 5.0 and book["rating"] == 2 and book["author"] is None
    quote = clean_quote({"text": "\u201cHi\u201d", "author": "A", "tags": ["B", "a"],
                         "page_url": "https://x/p"}, "t")
    assert quote["name_or_title"] == "Hi" and quote["tags"] == "a;b" and quote["price"] is None
