import csv
import json

from main import run_pipeline
from processing.cleaning import COLUMNS
from scrapers.books_scraper import BooksScraper
from scrapers.quotes_scraper import QuotesScraper
from tests.fakesite import FakeSession, book_html, books_page, quote_html, quotes_page

B = "https://books.toscrape.com/"
Q = "https://quotes.toscrape.com/"


def build(quotes_page2_fails=False):
    pages = {
        B: books_page([book_html("Good Book", "g/index.html"),
                       book_html(None, "bad/index.html"),                 # no title -> rejected
                       book_html("GOOD  book", "g2/index.html")]),        # duplicate of first
        Q: quotes_page([quote_html("Be kind", "Ann", ["Life", "love"]),
                        quote_html("Be  KIND", "ann", ["x"])], "/page/2/"),  # duplicate (case/space)
        Q + "page/2/": None if quotes_page2_fails else quotes_page([quote_html("Other", "Bob", [])]),
    }
    session = FakeSession(pages)
    return [BooksScraper(session=session, delay=0, fetch_details=False),
            QuotesScraper(session=session, delay=0)]


def test_full_pipeline_counts_reconcile(tmp_path):
    report = run_pipeline(build(), tmp_path)
    books = report["sources"]["Books to Scrape"]
    quotes = report["sources"]["Quotes to Scrape"]
    assert (books["raw_collected"], books["rejected_total"], books["duplicates"], books["final"]) == (3, 1, 1, 1)
    assert books["rejected_reasons"] == {"missing_name": 1}
    assert (quotes["raw_collected"], quotes["duplicates"], quotes["final"]) == (3, 1, 2)
    assert report["totals"]["reconciles"] is True

    rows = list(csv.DictReader(open(tmp_path / "final_dataset.csv", encoding="utf-8")))
    assert len(rows) == report["totals"]["final"] == 3
    assert list(rows[0].keys()) == COLUMNS
    assert {r["source"] for r in rows} == {"Books to Scrape", "Quotes to Scrape"}
    assert json.load(open(tmp_path / "summary_report.json"))["totals"]["final"] == 3
    quote = next(r for r in rows if r["author"] == "Ann")
    assert quote["tags"] == "life;love" and quote["price"] == "" and quote["name_or_title"] == "Be kind"


def test_one_source_failing_does_not_stop_the_other(tmp_path):
    scrapers = build(quotes_page2_fails=True)

    class Crashing(BooksScraper):
        def scrape(self):
            raise RuntimeError("boom")

    scrapers[0] = Crashing(session=scrapers[0].session, delay=0)
    report = run_pipeline(scrapers, tmp_path)
    assert report["sources"]["Books to Scrape"]["error"] == "RuntimeError: boom"
    assert report["sources"]["Quotes to Scrape"]["final"] == 1  # page 1 survived, page 2 failed
    assert report["sources"]["Quotes to Scrape"]["pages_failed"] == 1
    assert report["totals"]["reconciles"] is True
