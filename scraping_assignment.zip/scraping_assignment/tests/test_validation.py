from processing.validation import validate_record

GOOD = {"source": "Books to Scrape", "name_or_title": "T", "source_url": "https://x/1",
        "price": 10.0, "rating": 3}


def test_valid_record():
    assert validate_record(GOOD) == []


def test_optional_fields_may_be_none():
    assert validate_record({**GOOD, "price": None, "rating": None}) == []


def test_each_rule():
    assert "unknown_source" in validate_record({**GOOD, "source": "Other"})
    assert "missing_name" in validate_record({**GOOD, "name_or_title": None})
    assert "invalid_url" in validate_record({**GOOD, "source_url": "/rel"})
    assert "invalid_price" in validate_record({**GOOD, "price": -1})
    assert "invalid_price" in validate_record({**GOOD, "price": "12"})
    assert "invalid_rating" in validate_record({**GOOD, "rating": 6})


def test_multiple_problems_reported():
    assert len(validate_record({**GOOD, "name_or_title": "", "rating": 0})) == 2
